// updateForm.js
document.addEventListener("DOMContentLoaded", function() {
    // Mock data for demonstration purposes
    const initialData = {
        username: 'JohnDoe',
        email: 'john.doe@example.com'
    };

    // Populate form fields with initial data
    document.getElementById('username').value = initialData.username;
    document.getElementById('email').value = initialData.email;

    // Handle form submission
    const updateForm = document.getElementById('updateForm');
    updateForm.addEventListener('submit', handleSubmit);
});

function handleSubmit(event) {
    event.preventDefault();
    
    const formData = {
        username: document.getElementById('username').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    // You can call an API to update the data
    console.log('Form Submitted', formData);
    // Perform validation if necessary
}
