// aboutus.js

// Team members array with image paths
const teamMembers = [
    {
        id: "priyanshu",
        name: "Priyanshu Jaiswal",
        role: "Frontend and Backend Developer",
        description: "Priyanshu is responsible backend development, ensuring the seamless operation and user experience of the website.",
        image: "images/PriyanshuJ.jpg"
    },
    {
        id: "priyanshi-patel",
        name: "Priyanshi Patel",
        role: "Frontend Developer",
        description: "Priyanshi is responsible for creating beautiful and interactive user interfaces for the website, using modern frontend technologies.",
        image: "images/PriyanshiP.jpg"
    },
    {
        id: "ishan-joshi",
        name: "Ishan Joshi",
        role: "Cloud Engineer",
        description: "Ishan manages the cloud infrastructure and uploads data to the cloud, ensuring scalability and high availability for our services.",
        image: "images/IshanJ.jpg"
    },
    {
        id: "priyanshi-tomar",
        name: "Priyanshi Tomar",
        role: "Data Scientist",
        description: "Priyanshi works on data analysis and machine learning algorithms to provide valuable insights from the collected data.",
        image: "images/PriyanshiT.jpg"
    },
    {
        id: "aditi-lohiya",
        name: "Aditi Lohiya",
        role: "Power BI Data Visual Representation Expert",
        description: "Aditi specializes in creating interactive Power BI reports and dashboards to visualize data insights effectively for decision-making.",
        image: "images/AditiL.jpg"
    }
];

document.addEventListener("DOMContentLoaded", function() {
    const teamMembersContainer = document.getElementById('team-members');

    teamMembers.forEach(member => {
        const memberDiv = document.createElement('div');
        memberDiv.classList.add('team-member');
        memberDiv.id = member.id;

        const memberImage = document.createElement('img');
        memberImage.src = member.image;
        memberImage.alt = member.name;
        memberImage.classList.add('member-photo');
        memberImage.addEventListener('click', () => showDescription(member.id));

        const descriptionDiv = document.createElement('div');
        descriptionDiv.classList.add('description');
        descriptionDiv.innerHTML = `
            <p><strong>${member.name}</strong> - ${member.role}</p>
            <p>${member.description}</p>
        `;

        memberDiv.appendChild(memberImage);
        memberDiv.appendChild(descriptionDiv);
        teamMembersContainer.appendChild(memberDiv);
    });
});

function showDescription(id) {
    const activeMember = document.querySelector('.team-member.active');
    if (activeMember && activeMember.id !== id) {
        activeMember.classList.remove('active');
        activeMember.querySelector('.description').style.display = 'none';
    }

    const clickedMember = document.getElementById(id);
    if (clickedMember) {
        if (clickedMember.classList.contains('active')) {
            clickedMember.classList.remove('active');
            clickedMember.querySelector('.description').style.display = 'none';
        } else {
            clickedMember.classList.add('active');
            clickedMember.querySelector('.description').style.display = 'block';
        }
    }
}
