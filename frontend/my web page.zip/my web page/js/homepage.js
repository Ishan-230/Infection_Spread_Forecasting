document.addEventListener("DOMContentLoaded", function() {
    var video = document.getElementById('forecast-video');
    var lastScrollY = window.scrollY;

    function checkVideoVisibility() {
        var rect = video.getBoundingClientRect();
        var isVisible = (rect.top >= 0 && rect.bottom <= window.innerHeight);

        var currentScrollY = window.scrollY;
        var scrollingUp = currentScrollY < lastScrollY;

        if (scrollingUp && isVisible) {
            video.play();
        } else {
            video.pause();
        }

        lastScrollY = currentScrollY;
    }

    window.addEventListener('scroll', checkVideoVisibility);
    checkVideoVisibility();
});
