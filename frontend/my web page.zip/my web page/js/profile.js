document.addEventListener("DOMContentLoaded", function() {
    // Mock data for demonstration purposes
    const user = {
        username: 'JohnDoe',
        email: 'john.doe@example.com',
    };

    const usernameElement = document.getElementById('username');
    const emailElement = document.getElementById('email');
    const uploadButton = document.getElementById('uploadButton');
    const profileUploadForm = document.getElementById('profileUploadForm');

    // Populate user data
    usernameElement.textContent = user.username;
    emailElement.textContent = user.email;

    uploadButton.addEventListener('click', function() {
        uploadButton.style.display = 'none';
        profileUploadForm.style.display = 'block';
    });
});

function handleFileChange(event) {
    const file = event.target.files[0];
    console.log('Selected file:', file);
}

function handleUpload(event) {
    event.preventDefault();
    console.log('Uploading profile picture...');
}

function handleDelete(event) {
    event.preventDefault();
    if (window.confirm('Are you sure you want to delete your profile? This action cannot be undone.')) {
        console.log('Deleting profile...');
        // Add your profile deletion logic here, such as making an API call
        // For example:
        fetch('/api/deleteProfile', { method: 'DELETE' })
             .then(response => response.json())
            .then(data => console.log(data))
            .catch(error => console.error('Error:', error));
    }
}

function handleLogout(event) {
    event.preventDefault();
    console.log('Logging out...');
    // Add your logout logic here, such as making an API call or redirecting
    // For example:
    window.location.href = '/login';
}
