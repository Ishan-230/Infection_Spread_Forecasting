// forecasting.js
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById('forecast-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        generateForecast();
    });
});

function generateForecast() {
    const region = document.getElementById("region").value;
    const startDate = document.getElementById("start-date").value;
    const endDate = document.getElementById("end-date").value;

    // Mocked forecast data
    const mockData = `Forecast for ${region} from ${startDate} to ${endDate}`;
    
    const forecastOutput = document.getElementById("forecast-output");
    forecastOutput.innerHTML = `<p>${mockData}</p>`;
}
