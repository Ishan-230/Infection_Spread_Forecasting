document.addEventListener("DOMContentLoaded", function() {
    console.log('DOM fully loaded and parsed');
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        handleSubmit(event);
    });

    // Show the modal when the page loads
    document.getElementById('loginModal').style.display = 'block';
});

function handleSubmit(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    // Simple validation (email & password not empty)
    if (!email || !password) {
        errorMessage.textContent = 'Please fill in all fields';
        return;
    }
    
    // You can add your login logic here, such as calling an API
    console.log('Logging in with', email, password);

    // Reset the error message
    errorMessage.textContent = '';
}

function closeModal() {
    document.getElementById('loginModal').style.display = 'none';
}
