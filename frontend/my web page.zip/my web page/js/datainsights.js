// datainsights.js
document.addEventListener("DOMContentLoaded", function() {
    let chart = null;
    const dataList = [
        { label: "January", value: 30 },
        { label: "February", value: 45 },
        { label: "March", value: 25 }
    ];

    function renderChart() {
        const ctx = document.getElementById('dataChart').getContext('2d');

        if (chart) {
            chart.destroy();
        }

        chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: dataList.map(item => item.label),
                datasets: [{
                    label: 'Data Values',
                    data: dataList.map(item => item.value),
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                animation: {
                    duration: 1000,
                    easing: 'easeOutBounce'
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function renderDataList() {
        const dataListContainer = document.getElementById('dataList');
        dataListContainer.innerHTML = '';

        dataList.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.label}: ${item.value} `;

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', () => deleteData(item.label));

            listItem.appendChild(deleteButton);
            dataListContainer.appendChild(listItem);
        });
    }

    function addData(event) {
        event.preventDefault();
        const label = event.target.dataLabel.value;
        const value = parseInt(event.target.dataValue.value);

        dataList.push({ label, value });
        renderChart();
        renderDataList();
        event.target.reset();
    }

    function deleteData(label) {
        const index = dataList.findIndex(item => item.label === label);
        if (index !== -1) {
            dataList.splice(index, 1);
            renderChart();
            renderDataList();
        }
    }

    document.getElementById('dataForm').addEventListener('submit', addData);
    renderChart();
    renderDataList();
});
